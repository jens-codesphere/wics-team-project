# GirlHacks mobile checkpoint

This checkpoint:
- removes the duplicate root `/` route and uses `(tabs)/index.tsx` as the authenticated home route;
- uses canonical public routes (`/login`, `/signup`, `/groups`, `/`) instead of route-group names in navigation;
- upgrades interest matching to consensus-weighted group preferences;
- prevents duplicate interests in one member profile from being counted twice;
- adds small category aliases for the current mock-place taxonomy;
- shows the group consensus used by the recommendation engine on the recommendations screen.

## Verify locally

```powershell
npm install
npx expo start --clear
```

After Expo regenerates `.expo/types`, stop Metro and run:

```powershell
npx tsc --noEmit
```

## Functional test

1. Sign in as user A and fill in profile interests.
2. Create a group and copy its invite code.
3. Join from user B with different interests.
4. Refresh the group lobby and verify both members appear.
5. Tap **Find our match**.
6. Confirm the consensus card shows each interest with its member share and that rankings reflect shared interests.
