# Functional checkpoint before Figma

Implemented in this batch:
- Phase 4: Gemini explanations retained; backend configured for low thinking latency.
- Phase 5: top-three ballot, per-user yes/no votes, vote counts, deterministic tie-break by recommendation score, final selection.
- Phase 6: Gemini final itinerary, saved back to the finalized outing plan; Plans tab lists finalized plans.
- Phase 7 (demo-safe): map screen for the selected venue using react-native-maps and stored coordinates. Live Places/Routes remains optional because Google Maps Platform billing is unavailable.

Required backend actions after replacing the Supabase folder:
1. `npx supabase db push`
2. `npx supabase functions deploy explain-recommendations`
3. `npx supabase functions deploy generate-itinerary`

Then in mobile:
1. `npm install`
2. `npx tsc --noEmit`
3. `npx expo start --tunnel --clear`

The environment was not included in this archive. Preserve your existing `mobile/.env`.
