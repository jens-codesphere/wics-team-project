import { supabase } from '@/lib/supabase'
import {
  buildGroupPreferences,
  type GroupPreferences,
  type MemberProfile,
} from './group-preferences'
import { calculateInterestMatch } from './interest-match'
import { mockPlaces } from './mock-places'
import { fetchNearbyPlaces, type Coordinates } from './live-places'
import { rankPlaces, type PlaceCandidate } from './rank'

type MembershipRow = { user_id: string }
type ProfileRow = {
  id: string
  budget: number | null
  interests: string[] | null
  transportation: string | null
}

export type RecommendationBundle = {
  preferences: GroupPreferences
  places: ReturnType<typeof rankPlaces>
  source: 'live' | 'mock'
  warning: string | null
}

export async function getGroupRecommendationContext(
  groupId: string
): Promise<GroupPreferences> {
  const { data: group, error: groupError } = await supabase
    .from('groups')
    .select('id, budget')
    .eq('id', groupId)
    .single()

  if (groupError) throw groupError

  const { data: memberships, error: membershipError } = await supabase
    .from('group_members')
    .select('user_id')
    .eq('group_id', groupId)

  if (membershipError) throw membershipError

  const userIds = ((memberships ?? []) as MembershipRow[]).map(
    (membership) => membership.user_id
  )

  if (userIds.length === 0) {
    return buildGroupPreferences([], group.budget)
  }

  const { data: profiles, error: profilesError } = await supabase
    .from('profiles')
    .select('id, budget, interests, transportation')
    .in('id', userIds)

  if (profilesError) throw profilesError

  const memberProfiles: MemberProfile[] = ((profiles ?? []) as ProfileRow[]).map(
    (profile) => ({
      budget: profile.budget,
      interests: profile.interests,
      transportation: profile.transportation,
    })
  )

  return buildGroupPreferences(memberProfiles, group.budget)
}

function scoreCandidates(
  preferences: GroupPreferences,
  candidates: Omit<PlaceCandidate, 'interestMatch'>[]
) {
  return rankPlaces(
    candidates.map((place) => ({
      ...place,
      interestMatch: calculateInterestMatch(preferences.interests, place.categories),
    })),
    preferences.budget
  )
}

export async function getGroupRecommendationBundle(
  groupId: string,
  location?: Coordinates
): Promise<RecommendationBundle> {
  const preferences = await getGroupRecommendationContext(groupId)

  if (location) {
    try {
      const livePlaces = await fetchNearbyPlaces(
        location,
        preferences.interests.map((interest) => interest.name),
        preferences.transportation
      )

      if (livePlaces.length > 0) {
        return {
          preferences,
          places: scoreCandidates(preferences, livePlaces),
          source: 'live',
          warning: null,
        }
      }
    } catch (error) {
      console.warn('Live nearby-place lookup failed; using demo places.', error)
      return {
        preferences,
        places: scoreCandidates(preferences, mockPlaces),
        source: 'mock',
        warning: 'Live places are temporarily unavailable, so these are demo recommendations.',
      }
    }
  }

  return {
    preferences,
    places: scoreCandidates(preferences, mockPlaces),
    source: 'mock',
    warning: location
      ? 'No nearby places were returned, so these are demo recommendations.'
      : 'Location was unavailable, so these are demo recommendations.',
  }
}
