import { supabase } from '@/lib/supabase'

export type Coordinates = {
  latitude: number
  longitude: number
}

export type LivePlace = {
  id: string
  name: string
  address: string
  categories: string[]
  estimatedCost: number
  distanceMiles: number
  travelTimeMinutes: number
  availabilityMatch: number
  latitude: number
  longitude: number
}

type NearbyPlacesResponse = {
  places?: LivePlace[]
  error?: string
}

export async function fetchNearbyPlaces(
  location: Coordinates,
  interests: string[],
  transportation: string | null
): Promise<LivePlace[]> {
  const { data, error } = await supabase.functions.invoke<NearbyPlacesResponse>(
    'nearby-places',
    {
      body: {
        latitude: location.latitude,
        longitude: location.longitude,
        interests,
        transportation,
      },
    }
  )

  if (error) throw error
  if (data?.error) throw new Error(data.error)
  if (!data?.places) throw new Error('Nearby places service returned no places.')

  return data.places
}
