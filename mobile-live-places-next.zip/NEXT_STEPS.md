# Next checkpoint: live nearby recommendations

This build requests foreground device location and calls the Supabase `nearby-places` Edge Function. The Edge Function uses Google Places API (New) plus Routes API, then the existing deterministic group-consensus scorer ranks the returned candidates.

## Backend setup

1. In Google Cloud, enable Places API (New) and Routes API.
2. Create/restrict a server-side Google Maps Platform API key for those APIs.
3. From the Supabase project directory:

```bash
supabase secrets set GOOGLE_MAPS_API_KEY=YOUR_KEY
supabase functions deploy nearby-places
```

Do not put this key in Expo `.env`.

## Mobile verification

```bash
npm install
npx tsc --noEmit
npx expo start --clear
```

Open the app on a real phone, grant location permission, enter a group, and choose **Find our match**. The recommendations page should say **Live nearby places**. If the Edge Function or Google APIs are unavailable, the app deliberately falls back to demo places and displays a warning so the hackathon demo remains usable.
