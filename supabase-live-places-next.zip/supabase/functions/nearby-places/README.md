# nearby-places Edge Function

Server-side bridge from the mobile app to Google Places API (New) and Routes API.

Required secret:

```bash
supabase secrets set GOOGLE_MAPS_API_KEY=YOUR_SERVER_SIDE_GOOGLE_MAPS_KEY
```

Enable **Places API (New)** and **Routes API** in the same Google Cloud project, then deploy:

```bash
supabase functions deploy nearby-places
```

The key stays server-side in Supabase and is never bundled into the Expo app.
