const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

type RequestBody = {
  latitude: number
  longitude: number
  interests?: string[]
  transportation?: string | null
}

type GooglePlace = {
  id: string
  displayName?: { text?: string }
  formattedAddress?: string
  location?: { latitude?: number; longitude?: number }
  types?: string[]
  priceLevel?: string
  currentOpeningHours?: { openNow?: boolean }
}

const METERS_PER_MILE = 1609.344

const interestTypeMap: Record<string, string[]> = {
  cafe: ['cafe'],
  cafes: ['cafe'],
  coffee: ['cafe'],
  food: ['restaurant'],
  restaurant: ['restaurant'],
  restaurants: ['restaurant'],
  dining: ['restaurant'],
  park: ['park'],
  parks: ['park'],
  outdoors: ['park'],
  nature: ['park'],
  music: ['night_club'],
  games: ['bowling_alley'],
  game: ['bowling_alley'],
  entertainment: ['movie_theater', 'museum', 'tourist_attraction'],
  movies: ['movie_theater'],
  movie: ['movie_theater'],
  museum: ['museum'],
  shopping: ['shopping_mall'],
}

function placeTypesFor(interests: string[]) {
  const mapped = interests.flatMap((interest) =>
    interestTypeMap[interest.trim().toLowerCase()] ?? []
  )
  const defaults = ['restaurant', 'cafe', 'park', 'movie_theater', 'museum', 'tourist_attraction']
  return [...new Set(mapped.length ? mapped : defaults)].slice(0, 20)
}

function estimatedCost(priceLevel?: string) {
  switch (priceLevel) {
    case 'PRICE_LEVEL_FREE': return 0
    case 'PRICE_LEVEL_INEXPENSIVE': return 10
    case 'PRICE_LEVEL_MODERATE': return 22
    case 'PRICE_LEVEL_EXPENSIVE': return 45
    case 'PRICE_LEVEL_VERY_EXPENSIVE': return 75
    default: return 18
  }
}

function travelMode(value?: string | null) {
  const normalized = value?.toLowerCase() ?? ''
  if (normalized.includes('walk')) return 'WALK'
  if (normalized.includes('bike') || normalized.includes('bicycle')) return 'BICYCLE'
  if (normalized.includes('transit') || normalized.includes('public') || normalized.includes('bus') || normalized.includes('train')) return 'TRANSIT'
  return 'DRIVE'
}

function parseDurationSeconds(duration?: string) {
  if (!duration) return null
  const match = duration.match(/^([0-9.]+)s$/)
  return match ? Number(match[1]) : null
}

async function getRouteMetrics(
  apiKey: string,
  origin: { latitude: number; longitude: number },
  destinations: { latitude: number; longitude: number }[],
  mode: string
) {
  if (destinations.length === 0) return []

  const response = await fetch('https://routes.googleapis.com/distanceMatrix/v2:computeRouteMatrix', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-Goog-Api-Key': apiKey,
      'X-Goog-FieldMask': 'originIndex,destinationIndex,duration,distanceMeters,status,condition',
    },
    body: JSON.stringify({
      origins: [{ waypoint: { location: { latLng: origin } } }],
      destinations: destinations.map((destination) => ({
        waypoint: { location: { latLng: destination } },
      })),
      travelMode: mode,
    }),
  })

  if (!response.ok) {
    throw new Error(`Google Routes request failed (${response.status}): ${await response.text()}`)
  }

  const result = await response.json()
  return Array.isArray(result) ? result : []
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })

  try {
    const apiKey = Deno.env.get('GOOGLE_MAPS_API_KEY')
    if (!apiKey) throw new Error('GOOGLE_MAPS_API_KEY is not configured for this Edge Function.')

    const body = (await req.json()) as RequestBody
    if (!Number.isFinite(body.latitude) || !Number.isFinite(body.longitude)) {
      return new Response(JSON.stringify({ error: 'Valid latitude and longitude are required.' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      })
    }

    const placesResponse = await fetch('https://places.googleapis.com/v1/places:searchNearby', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Goog-Api-Key': apiKey,
        'X-Goog-FieldMask': 'places.id,places.displayName,places.formattedAddress,places.location,places.types,places.priceLevel,places.currentOpeningHours.openNow',
      },
      body: JSON.stringify({
        includedTypes: placeTypesFor(body.interests ?? []),
        maxResultCount: 12,
        rankPreference: 'POPULARITY',
        locationRestriction: {
          circle: {
            center: { latitude: body.latitude, longitude: body.longitude },
            radius: 8000,
          },
        },
      }),
    })

    if (!placesResponse.ok) {
      throw new Error(`Google Places request failed (${placesResponse.status}): ${await placesResponse.text()}`)
    }

    const placesJson = await placesResponse.json() as { places?: GooglePlace[] }
    const googlePlaces = (placesJson.places ?? []).filter(
      (place) => place.location?.latitude != null && place.location?.longitude != null
    )

    const destinations = googlePlaces.map((place) => ({
      latitude: place.location!.latitude!,
      longitude: place.location!.longitude!,
    }))

    let routes: Array<Record<string, unknown>> = []
    try {
      routes = await getRouteMetrics(
        apiKey,
        { latitude: body.latitude, longitude: body.longitude },
        destinations,
        travelMode(body.transportation)
      )
    } catch (error) {
      console.warn('Routes lookup failed; returning places with straight-line fallback metrics.', error)
    }

    const routeByDestination = new Map<number, Record<string, unknown>>()
    for (const route of routes) {
      if (typeof route.destinationIndex === 'number') routeByDestination.set(route.destinationIndex, route)
    }

    const places = googlePlaces.map((place, index) => {
      const route = routeByDestination.get(index)
      const distanceMeters = typeof route?.distanceMeters === 'number' ? route.distanceMeters : null
      const durationSeconds = typeof route?.duration === 'string' ? parseDurationSeconds(route.duration) : null

      // If Routes is unavailable, approximate only enough to keep the demo resilient.
      const latDelta = (place.location!.latitude! - body.latitude) * 69
      const lngDelta = (place.location!.longitude! - body.longitude) * 54.6
      const straightLineMiles = Math.sqrt(latDelta ** 2 + lngDelta ** 2)

      return {
        id: place.id,
        name: place.displayName?.text ?? 'Nearby place',
        address: place.formattedAddress ?? '',
        categories: place.types ?? [],
        estimatedCost: estimatedCost(place.priceLevel),
        distanceMiles: distanceMeters != null ? distanceMeters / METERS_PER_MILE : straightLineMiles,
        travelTimeMinutes: durationSeconds != null
          ? Math.max(1, Math.round(durationSeconds / 60))
          : Math.max(1, Math.round(straightLineMiles * 3)),
        availabilityMatch: place.currentOpeningHours?.openNow === true
          ? 1
          : place.currentOpeningHours?.openNow === false ? 0.25 : 0.7,
        latitude: place.location!.latitude!,
        longitude: place.location!.longitude!,
      }
    })

    return new Response(JSON.stringify({ places }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  } catch (error) {
    console.error(error)
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'Unexpected server error.' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }
})
